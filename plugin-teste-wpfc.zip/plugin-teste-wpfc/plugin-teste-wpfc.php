<?php
/*
Plugin Name: Plugin Teste WPFC
Description: Plugin básico Wordpress com uma página de administração para o desenvolvimento de projetos e novas funcionalidades...
Author: Fernando Celmer
Version: 0.1
*/
// Include wpfc-functions.php, use require_once to stop the script if wpfc-functions.php is not found
require_once plugin_dir_path(__FILE__) . 'includes/wpfc-functions.php';
?>