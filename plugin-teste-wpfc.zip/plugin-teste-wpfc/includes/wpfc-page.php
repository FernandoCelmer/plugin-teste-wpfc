<div class="wrap">
  <h1>Plugin Teste WPFC</h1>
  <p>Plugin básico Wordpress com uma página de administração para o desenvolvimento de projetos e novas funcionalidades...</p>
  <p>Site: <a href="www.fernandocelmer.com">www.fernandocelmer.com</a></p>
  <p>E-mail: <a href="www.fernandocelmer.com">email@fernandocelmer.com</p>
</div>
